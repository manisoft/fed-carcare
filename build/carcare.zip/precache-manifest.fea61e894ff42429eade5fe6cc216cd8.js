self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "be5ad6383411f062cf8894d1c9ab0c4a",
    "url": "/index.html"
  },
  {
    "revision": "d25c2fbfe1e8a4f7ba4d",
    "url": "/static/css/main.e30a0352.chunk.css"
  },
  {
    "revision": "e4e5b2c14a7e18e32f66",
    "url": "/static/js/2.def34f74.chunk.js"
  },
  {
    "revision": "d25c2fbfe1e8a4f7ba4d",
    "url": "/static/js/main.9fd873da.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "c207f59693a15a036da0efd77124cd2d",
    "url": "/static/media/back.c207f596.svg"
  },
  {
    "revision": "21fff00caddac66220d5227ada181b55",
    "url": "/static/media/carcare.21fff00c.svg"
  },
  {
    "revision": "598ca6822c085ba635ba04e99fab1a86",
    "url": "/static/media/gas.598ca682.svg"
  },
  {
    "revision": "3dcf1c85f6e84e289f6071f821efb751",
    "url": "/static/media/oil.3dcf1c85.svg"
  }
]);